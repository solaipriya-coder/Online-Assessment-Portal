<?php
?>

<html>
    <head>
        <link rel="stylesheet" href="css/star.css">
    </head>
    <body>
        <div class="star"></div>
    </body>
</html>