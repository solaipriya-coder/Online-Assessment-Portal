<?php
session_start();
if ( !isset($_SESSION['Users'])!="" ) 
{
    header("Location: logout.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	 <meta charset="UTF-8">
	 <meta name="viewport" content="width=device-width, initial-scale=1.0">
	 
	 <meta http-equiv="X-UA-Compatible" content="ie=edge">
	 <title>Interview Experience</title>
	 <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
	<script>tinymce.init({selector:'textarea'});</script>
	

	 <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.css" />
	 <link rel="stylesheet" href="assets/css/interview.css">
</head>
<body>
</body>
	<div class="container">
		<div class="wrapper">
			<div class="heading">
				<h1>Interview Experience</h1>
			</div>
			<div class="info">
				<form>
					<p>
						<label>Company Name</label>
						<input type="text" name="title"  required="required">
					</p>
					<p>
						<label>Number of Rounds</label>
						<input type="Number" name="des" min="3" max="10"  required="required">
					</p>
					<p>
						<label>Select Difficulty</label>
						<select id="difficulty" name="difficulty">
						  <option value="easy">Easy</option>
						  <option value="medium">Medium</option>
						  <option value="hard">Hard</option>
						 </select> 
													
					</p>
					</br>
					<p class="full">
						<label>Share your experience</label>
						<textarea name="post" rows="30"></textarea>
					
					</p>	
					
					
					<p class="full">	
						<button>Submit</button>
					</p>
				</form>
			</div>
		</div>
	</div>
</html>