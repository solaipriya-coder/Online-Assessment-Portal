<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Notes</title>
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.css" />
    <script>
var stateObject = {
"First":{
  "CSE":["Engineering Physics","Engineering Chemistry","Engineering Maths","Engineering Graphics","Python","English"],
  "CHEM":["Engineering Physics","Engineering Chemistry","Engineering Maths","Engineering Graphics","Python","English"],
  "ECE":["Engineering Physics","Engineering Chemistry","Engineering Maths","Engineering Graphics","Python","English"],
  "MECH":["Engineering Physics","Engineering Chemistry","Engineering Maths","Engineering Graphics","Python","English"],
},

"Second": {
"CSE":["Technical English","Engineering Maths II","BEEE","C","Physics","EVS"],
  "CHEM":["Technical English","Engineering Maths II","POC","Chemistry","Physics","BME"],
  "ECE":["Technical English","Physics","Circuit Analysis","Electronic Devices","BEI"],
},

"Third": {
"CSE":["Data Structures","Discrete Maths","OOPS","DPSD","Communication Engineering"],
  "CHEM":["Probability and Statistics","PC","FM","Principles of Electrical and Electronic Engineering","OC"],
  "ECE":["Linear Algebra","DS","CS","EC-I","DE"],
},

"Fourth": {
"CSE":["PQT","CA","DBMS","OS","Software Engineering","DAA"],
  "CHEM":["Numeric Methods","EVS","IMA","Thermodynamics I","Physical Chemistry","MO"],
  "ECE":["Probability and Random Process","EC-II","EF","LIC","EVS","CT"],
},

"Fifth": {
"CSE":["Algebra and Number Theory","TOC","Open Elective","MPMC","CN","OOAD"],
  "CHEM":["CRE I","CPI","MT I","HT"],
  "ECE":["DC","DSP","CN","CA","OE I","PE I"],
},

"Sixth": {
"CSE":["IP","Elective","DS","CD","MC","AI"],
  "CHEM":["CRE II","MT II","Thermodynamics II","PEE","Instrumentation"],
  "ECE":["MPMC","VLSI","WC","Transmission Lines and RF Systems","Professional Elective II"],
},

"Seventh": {
"CSE":["POM","Crytography","Cloud Computing","Open Elective","Professional ElectiveII","Professional ElectiveIII"],
  "CHEM":["TP","PED"],
  "ECE":["PE - II","OE II","Adhoc and Wireless Sensor Networks","OC","AME"],
},

"Eighth": {
"CSE":["Professional Elective IV","Professional Elective V"],
  "ECE":["Kaatpaadi","Aalpuram","Solingar","Perumugai"],
  "MECH":["Kaatpaadi","Aalpuram","Solingar","Perumugai"],
  "EEE":["Kaatpaadi","Aalpuram","Solingar","Perumugai"],
  "ICE":["Kaatpaadi","Aalpuram","Solingar","Perumugai"],
},

}
window.onload = function () {
var countySel = document.getElementById("countySel"),
stateSel = document.getElementById("stateSel"),
districtSel = document.getElementById("districtSel");
for (var country in stateObject) {
countySel.options[countySel.options.length] = new Option(country, country);
}
countySel.onchange = function () {
stateSel.length = 1; // remove all options bar first
districtSel.length = 1; // remove all options bar first
if (this.selectedIndex < 1) return; // done
for (var state in stateObject[this.value]) {
stateSel.options[stateSel.options.length] = new Option(state, state);
}
}
countySel.onchange(); // reset in case page is reloaded
stateSel.onchange = function () {
districtSel.length = 1; // remove all options bar first
if (this.selectedIndex < 1) return; // done
var district = stateObject[countySel.value][this.value];
for (var i = 0; i < district.length; i++) {
districtSel.options[districtSel.options.length] = new Option(district[i], district[i]);
}
}
}
</script>
  <style type="text/css">
  	*{
    box-sizing: border-box;
  }

body{
  background:#efa8e4;
  color:#485e74;
  line-height:1.6;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  padding:0.2em;
}

@import url(//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css);

.container{
  max-width:100%;
  margin-left:auto;
  margin-right:auto;
  padding:1em;
}

.brand{
  text-align: center;
}

.brand span{
  color:#fff;
}

.wrapper{
  box-shadow: 0 0 20px 0 rgba(72,94,116,0.7);
}

.wrapper > *{
  padding: 1em;
}

.company-info{
  background:#f8e1f4;
  font-size: 18px;
}

.company-info h3, .company-info ul{
  text-align: center;
  margin:0 0 1rem 0;
}

.contact{
  background:#fff0f5;
  height: 500px;
}

/* FORM STYLES */
.contact form{
  display: grid;
  grid-template-columns: 0.7fr 2fr;
  grid-gap:20px;
}

.contact form label .la{
  display:block;
}

.contact form p{
  margin:0;
}

.contact form .full{
  grid-column: 1 / 3;
}


.custom {
  position: relative;
  padding-left: 25px;
  margin-bottom: 12px;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* LARGE SCREENS */
@media(min-width:700px){
  .wrapper{
    display: grid;
    grid-template-columns: 1fr 2fr;
  }

  .wrapper > *{
    padding:0.5em;
  }

  .company-info h3, .company-info ul, .brand{
    text-align: left;
  }
}
  </style>
</head>
<body>
  <div class="container">
    <h1 class="brand"><span>Read</span> Your <span> Notes!! </span> </h1>
    <div class="wrapper animated bounceInLeft">
      <div class="company-info">
        <p style="color: #efa8e4;font-weight: bold">Select Semester
        <select name="country" id="countySel" size="1" style="height: 30px" required >
        <option value="" selected="selected" >Select Semester first</option></select></p>
        <p style="color: #efa8e4;font-weight: bold">Select Department
        <select name="state" id="stateSel" size="1" style="height: 30px" required>
        <option value="" selected="selected"> Select Semester first</option>
        </select></p>
        <p style="color: #efa8e4;font-weight: bold">Select Subject
        <select name="district" id="districtSel" size="1" style="height: 30px" required>
        <option value="" selected="selected">Select Department first</option>
        </select></p>
        <p style="color:#efa8e4;font-weight: bold;">Uploaded Staff Name:</p>
      </div>
      <div class="contact">
        <div style="border:1px solid red;width: 100%;height: 45%;"></div><br>
        <div style="border:1px solid red;width: 100%;height: 45%;"></div>
      </div>
    </div>
  </div>
</body>
</html>